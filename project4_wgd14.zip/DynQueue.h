#include <iostream>

using namespace std;

template <class T>
class Dynque
{
    private:
            struct QueueNode
            {
                T value;
                QueueNode *next;
            };

            QueueNode *front;
            QueueNode *rear;
            int numItems;
    
    public:
            Dynque(){numItems=0; front=NULL; rear=NULL;};
            ~Dynque();
            void enqueue(T);
            void dequeue(T &);
            bool isEmpty();
};

// TODO
template <class T>
void Dynque<T>::enqueue(T new_val)
{
    QueueNode *newNode = nullptr;

    newNode = new QueueNode;
    newNode->value = new_val;
    newNode->next = nullptr;
    if (isEmpty())
    {
        front = newNode;
        rear = newNode;
    }
    else 
    {
        rear->next = newNode;
        rear = newNode;
    }
    
    numItems++;
}

// TODO
template <class T>
void Dynque<T>::dequeue(T &val)
{
    QueueNode *temp = nullptr;

    if (isEmpty())
    {
        cout << "The queue is empty" << endl;
    }
    else
    {
        val = front->value;

        temp = front;
        front = front->next;
        delete temp;

        numItems--;
    }
}

// TODO
template <class T>
bool Dynque<T>::isEmpty()
{
    bool status;

    if (numItems > 0)
        status = false;
    else 
        status = true;
    return status;
}

// TODO
template <class T>
Dynque<T>::~Dynque()
{
   T trash;

    while (!isEmpty())
    {
        dequeue(trash);
    }
}

