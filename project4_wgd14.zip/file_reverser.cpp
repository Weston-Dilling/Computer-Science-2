#include <iostream>
#include <fstream>
#include "DynStack.h" 

using namespace std;

int main( int argc, char *argv[] )
{
    if ( argc != 2 )
    {
        cout << "Wrong number of arguments" << endl;
        return 1;
    }

    DynStack<char> stack;
    ifstream fin;
    ofstream fout;
    char chars, del_char;
    
    fin.open( argv[1] );
    fout.open( "output_reverse.txt");

    //creating the stack
    while ( fin.get(chars) )
    {
        stack.push(chars);
    }

    //popping
    while (!stack.isEmpty())
    {
        stack.pop(del_char);
        fout << del_char;
    }

    fin.close();
    fout.close();
}