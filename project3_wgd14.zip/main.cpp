// This program demonstrates the linked list template.

#include <iostream>
#include "LinkedList.h"

using namespace std;

int main()
{
   // Define a LinkedList object.
  
   cout << "First creating a List with nodes that contain integer numbers." << endl << endl;
   LinkedList<int> list;

   // Append three characters to the list.
   list.appendNode(1);
   list.appendNode(3);
   // Display the values in the list.
   cout << "Here are the initial values:\n";
   list.displayList();
   cout << endl;

   // Insert another FeetInches object.
   cout << "Now inserting the value in the middle.\n";
   list.insertNode(2);

   // Display the values in the list.
   cout << "Here are the nodes now.\n";
   list.displayList();
   cout << endl;


   cout << "adding random numbers.\n";
   list.appendNode(16);	
   list.appendNode(18);
   list.appendNode(17);
   list.appendNode(9);
   list.appendNode(5);

   cout << "Here are the values.\n"; 
   list.displayList();
   cout << endl;

   cout << "Sorting.\n\n";
   list.sort();

   cout << "Sorted Values \n";
   list.displayList();

   cout << endl;

   // Delete the last node.
   cout << "Now deleting the last node.\n";
   list.deleteNode(3);

   // Display the values in the list.
   cout << "Here are the nodes left.\n";
   list.displayList();


   cout << endl << "**************************************" << endl;

   cout << "Now creating a List with nodes that contain real numbers." << endl << endl;
   
   LinkedList<float> list1;

   // Append three characters to the list.
   list1.appendNode(9.1);
   list1.appendNode(8.3);
   list1.appendNode(7.3);
   list1.appendNode(5.3);
   list1.appendNode(3.3);
   list1.appendNode(2.3);


   // Display the values in the list.
   cout << "Here are the initial values:\n";
   list1.displayList();
   cout << endl;


   cout << "Sorting\n";
   list1.sort();
   list1.displayList();

   cout << endl;

   // Insert another FeetInches object.
   cout << "Now inserting the value in the middle.\n";
   list1.insertNode(2.2);

   // Display the values in the list.
   cout << "Here are the nodes now.\n";
   list1.displayList();
   cout << endl;

   // Delete the last node.
   cout << "Now deleting the last node.\n";
   list1.deleteNode(3.3);

   // Display the values in the list.
   cout << "Here are the nodes left.\n";
   list1.displayList();
   cout << endl;


   cout << "making a list of chars with duplicates\n";
   LinkedList<char> list2;
   list2.appendNode('d');
   list2.appendNode('c');
   list2.appendNode('b');
   list2.appendNode('a');
   list2.appendNode('c');
   list2.appendNode('b');
   list2.appendNode('a');


   cout << "inital values" << endl;
   list2.displayList();
   cout << endl;

   cout << "sorted values" << endl;
   list2.sort();
   list2.displayList();
   cout << endl;

   cout << "sorting already sorted values" << endl;
   list2.sort();
   list2.displayList();


   return 0;
}
