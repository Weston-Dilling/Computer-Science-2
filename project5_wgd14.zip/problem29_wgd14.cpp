#include <iostream>
#include <set>
#include <cmath>

using namespace std;

int main()
{
    set <double> set1;
    for (int i = 2; i <= 100; i++)
    {
        for(int j = 2; j <= 100; j++)
        {
            set1.insert(pow(i, j));
        }    
    }
    cout << set1.size() << endl;

    return 0;
}