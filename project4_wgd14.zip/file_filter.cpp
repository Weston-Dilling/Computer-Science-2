#include <iostream>
#include <fstream>
#include "DynQueue.h" 

using namespace std;

int main( int argc, char *argv[] )
{
    if ( argc != 2 )
    {
        cout << "Wrong number of arguments" << endl;
        return 1;
    }

    Dynque<char> que;
    ifstream fin;
    ofstream fout;
    char chars, del_char;
    
    fin.open( argv[1] );
    fout.open( "output_filter.txt");

    //creating the queue
    while ( fin.get(chars) )
    {
        que.enqueue(chars);
    }

    //dequeing
    while (!que.isEmpty())
    {
        que.dequeue(del_char);
        del_char = toupper(del_char);
        fout << del_char;
    }

    fin.close();
    fout.close();
}