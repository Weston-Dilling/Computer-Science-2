#include <iostream>
#include <cstring>
#include <map> 

using namespace std;

int main ()
{
	int i_LargestChainSize = 0;
	int i_LargestChainNumber = 0;
    int i_currentChainNumber = 0;

	const int n = 1000000;
    map <int, int> map1;
    map <int, int>::iterator itr;
	int *Array = new int[n];
	memset(Array,0,n);
	for (int i = 1; i < 1000001; i++) {
		long b = i;
		int i_Counter = 1;
		while (!(b == 1)) {
			((b%2) == 0)? b = b/2 : b = (3*b + 1);
			i_Counter += 1;
			if ((b-1 < n) && !(Array[b-1] == 0)) {
                auto skip = map1.find(b-1);
				if ((b-1 < n) && (skip->first == 0))
                {
                    i_currentChainNumber = itr->first;
                    i_Counter += itr->second;
                }
                i_Counter += Array[b-1];
				b = 1;
			}
		}
        map1.insert( pair <int, int> (i, i_currentChainNumber));
		Array[i-1] = i_Counter;
		if (i_Counter > i_LargestChainSize) {
			i_LargestChainSize = i_Counter;
			i_LargestChainNumber = i;
		}
	}
	cout << i_LargestChainNumber << endl;
}