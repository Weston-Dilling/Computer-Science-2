#include <iostream>

using namespace std;

template <class T>
class DynStack
{
    private:
            struct StackNode
            {
                T value;
                StackNode *next;
            };

            StackNode *top;
    
    public:
            DynStack(){top = NULL;};
            ~DynStack();
            void push(T);
            void pop(T &);
            bool isEmpty();
};

// TODO
template <class T>
void DynStack<T>::push(T new_value)
{
    StackNode *newNode = nullptr;
    newNode = new StackNode;
    newNode->value = new_value;

    if (isEmpty())
    {
        top = newNode;
        newNode->next = nullptr;
    }
    else
    {
        newNode->next = top;
        top = newNode;
    }
}

// TODO
template <class T>
DynStack<T>::~DynStack()
{
    StackNode *nodePtr = nullptr, *nextNode = nullptr;
    nodePtr = top;
    while (nodePtr != nodePtr)
    {
        nextNode = nodePtr->next;
        delete nodePtr;
        nodePtr = nextNode;
    }
}

// TODO
template <class T>
bool DynStack<T>::isEmpty()
{
    bool status;

    if (!top)
        status = true;
    else
        status = false;
    return status;
}

// TODO
template <class T>
void DynStack<T>::pop(T &val)
{
    StackNode *temp = nullptr;

    if (isEmpty())
    {
        cout << "The stack is empty " << endl;
    }
    else
    {
        val = top->value;
        temp = top->next;
        delete top;
        top = temp;
    }   
}